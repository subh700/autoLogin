import os, time
from dotenv import load_dotenv
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

load_dotenv()

URL = os.getenv("PORTAL_URL", "http://10.100.20.1:8090/httpclient.html")
USER = os.getenv("PORTAL_USERNAME")
PWD = os.getenv("PORTAL_PASSWORD")
HEADLESS = os.getenv("SELENIUM_HEADLESS", "false").lower() in ("true", "1")
INTERVAL = int(os.getenv("CHECK_INTERVAL", "60"))

def login():
    opts = webdriver.ChromeOptions()
    if HEADLESS:
        opts.add_argument("--headless=new")
    opts.add_argument("--disable-gpu")
    opts.add_argument("--no-sandbox")

    driver = webdriver.Chrome(options=opts)
    try:
        driver.get(URL)
        WebDriverWait(driver, 5).until(EC.presence_of_element_located((By.ID, "username"))).send_keys(USER)
        driver.find_element(By.ID, "password").send_keys(PWD)
        driver.execute_script("submitRequest();")
        time.sleep(3)
        print(f"[{time.strftime('%H:%M:%S')}] Selenium login submitted for {USER}", flush=True)
    except Exception as e:
        print(f"[{time.strftime('%H:%M:%S')}] Selenium error: {e}", flush=True)
    finally:
        driver.quit()

if __name__ == "__main__":
    if not USER or not PWD:
        raise SystemExit("Error: Set PORTAL_USERNAME and PORTAL_PASSWORD in .env")

    print(f"[{time.strftime('%H:%M:%S')}] Selenium Auto-Login active for {USER}...", flush=True)
    while True:
        login()
        time.sleep(INTERVAL)
