"""
NIT Sikkim / Sophos Captive Portal - Modern Desktop GUI Application
Supports Custom Username, Password, User Profiles, and Auto-Reconnect.
Cross-Platform: Windows (.exe) & Linux (.deb).
"""

import os
import sys
import time
import threading
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime

import portal_core

class ModernPortalGUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("NIT Sikkim - Captive Portal Manager")
        self.root.geometry("560x700")
        self.root.minsize(500, 620)

        # Theme Colors
        self.BG_MAIN = "#1e1e2e"
        self.BG_CARD = "#2a2b3d"
        self.BG_INPUT = "#181825"
        self.FG_TEXT = "#cdd6f4"
        self.FG_MUTED = "#a6adc8"
        self.COLOR_GREEN = "#a6e3a1"
        self.COLOR_RED = "#f38ba8"
        self.COLOR_BLUE = "#89b4fa"
        self.COLOR_YELLOW = "#f9e2af"
        self.BTN_CONNECT = "#2ecc71"
        self.BTN_DISCONNECT = "#e74c3c"

        self.root.configure(bg=self.BG_MAIN)

        # Load persisted custom settings
        self.settings = portal_core.load_settings()
        self.is_monitoring = True
        self.auto_reconnect = tk.BooleanVar(value=self.settings.get("auto_reconnect", True))
        self.is_online = False
        self.is_busy = False

        self._build_ui()
        self._start_background_worker()

    def _build_ui(self):
        # ------------------ Header ------------------
        header_frame = tk.Frame(self.root, bg=self.BG_MAIN)
        header_frame.pack(fill="x", padx=22, pady=(15, 8))

        title_lbl = tk.Label(
            header_frame,
            text="NIT SIKKIM PORTAL MANAGER",
            font=("Segoe UI", 15, "bold"),
            fg=self.COLOR_BLUE,
            bg=self.BG_MAIN
        )
        title_lbl.pack(anchor="w")

        subtitle_lbl = tk.Label(
            header_frame,
            text="Custom Credentials & Auto-Connection Keeper",
            font=("Segoe UI", 9),
            fg=self.FG_MUTED,
            bg=self.BG_MAIN
        )
        subtitle_lbl.pack(anchor="w")

        # ------------------ 1. Status Banner Card ------------------
        status_card = tk.Frame(self.root, bg=self.BG_CARD, bd=0, relief="flat", padx=16, pady=12)
        status_card.pack(fill="x", padx=22, pady=(0, 10))

        status_header = tk.Frame(status_card, bg=self.BG_CARD)
        status_header.pack(fill="x")

        self.status_dot = tk.Label(status_header, text="●", font=("Segoe UI", 16), fg=self.COLOR_YELLOW, bg=self.BG_CARD)
        self.status_dot.pack(side="left", padx=(0, 6))

        self.status_text = tk.Label(status_header, text="Checking connection...", font=("Segoe UI", 12, "bold"), fg="#ffffff", bg=self.BG_CARD)
        self.status_text.pack(side="left")

        self.last_check_lbl = tk.Label(status_header, text="", font=("Segoe UI", 8), fg=self.FG_MUTED, bg=self.BG_CARD)
        self.last_check_lbl.pack(side="right")

        self.status_subtext = tk.Label(status_card, text="Testing gateway authorization...", font=("Segoe UI", 9), fg=self.FG_MUTED, bg=self.BG_CARD)
        self.status_subtext.pack(anchor="w", pady=(4, 0))

        # ------------------ 2. Action Buttons ------------------
        btn_frame = tk.Frame(self.root, bg=self.BG_MAIN)
        btn_frame.pack(fill="x", padx=22, pady=(0, 10))

        self.connect_btn = tk.Button(
            btn_frame,
            text="CONNECT / SIGN IN",
            font=("Segoe UI", 10, "bold"),
            bg=self.BTN_CONNECT,
            fg="#ffffff",
            activebackground="#27ae60",
            activeforeground="#ffffff",
            relief="flat",
            cursor="hand2",
            padx=15,
            pady=9,
            command=self.on_connect_clicked
        )
        self.connect_btn.pack(side="left", fill="x", expand=True, padx=(0, 5))

        self.disconnect_btn = tk.Button(
            btn_frame,
            text="DISCONNECT",
            font=("Segoe UI", 10, "bold"),
            bg=self.BTN_DISCONNECT,
            fg="#ffffff",
            activebackground="#c0392b",
            activeforeground="#ffffff",
            relief="flat",
            cursor="hand2",
            padx=15,
            pady=9,
            command=self.on_disconnect_clicked
        )
        self.disconnect_btn.pack(side="right", fill="x", expand=True, padx=(5, 0))

        # ------------------ 3. Custom Credentials Card ------------------
        cred_card = tk.LabelFrame(
            self.root,
            text=" Custom Credentials & Profiles ",
            font=("Segoe UI", 9, "bold"),
            fg=self.COLOR_BLUE,
            bg=self.BG_CARD,
            bd=1,
            relief="groove",
            padx=14,
            pady=10
        )
        cred_card.pack(fill="x", padx=22, pady=(0, 10))

        # Username Input
        tk.Label(cred_card, text="Username:", font=("Segoe UI", 9, "bold"), fg=self.FG_TEXT, bg=self.BG_CARD).grid(row=0, column=0, sticky="w", pady=4)
        self.user_entry = tk.Entry(cred_card, font=("Segoe UI", 10), bg=self.BG_INPUT, fg="#ffffff", insertbackground="#ffffff", relief="flat")
        self.user_entry.insert(0, self.settings.get("username", ""))
        self.user_entry.grid(row=0, column=1, sticky="ew", padx=8, pady=4)

        # Password Input
        tk.Label(cred_card, text="Password:", font=("Segoe UI", 9, "bold"), fg=self.FG_TEXT, bg=self.BG_CARD).grid(row=1, column=0, sticky="w", pady=4)
        self.pass_entry = tk.Entry(cred_card, font=("Segoe UI", 10), show="●", bg=self.BG_INPUT, fg="#ffffff", insertbackground="#ffffff", relief="flat")
        self.pass_entry.insert(0, self.settings.get("password", ""))
        self.pass_entry.grid(row=1, column=1, sticky="ew", padx=8, pady=4)

        self.show_pass_var = tk.BooleanVar(value=False)
        self.show_pass_chk = tk.Checkbutton(
            cred_card,
            text="Show",
            font=("Segoe UI", 8),
            variable=self.show_pass_var,
            command=self._toggle_password_visibility,
            bg=self.BG_CARD,
            fg=self.FG_MUTED,
            selectcolor=self.BG_INPUT,
            activebackground=self.BG_CARD
        )
        self.show_pass_chk.grid(row=1, column=2, sticky="w")

        # Gateway URL Input
        tk.Label(cred_card, text="Gateway:", font=("Segoe UI", 9), fg=self.FG_TEXT, bg=self.BG_CARD).grid(row=2, column=0, sticky="w", pady=4)
        self.url_entry = tk.Entry(cred_card, font=("Segoe UI", 9), bg=self.BG_INPUT, fg="#ffffff", insertbackground="#ffffff", relief="flat")
        self.url_entry.insert(0, self.settings.get("portal_url", "http://10.100.20.1:8090/httpclient.html"))
        self.url_entry.grid(row=2, column=1, columnspan=2, sticky="ew", padx=8, pady=4)

        cred_card.columnconfigure(1, weight=1)

        # Options Row: Auto Reconnect & Save
        opt_frame = tk.Frame(cred_card, bg=self.BG_CARD)
        opt_frame.grid(row=3, column=0, columnspan=3, sticky="ew", pady=(8, 2))

        self.auto_chk = tk.Checkbutton(
            opt_frame,
            text="Auto-reconnect on WiFi drop",
            variable=self.auto_reconnect,
            font=("Segoe UI", 9),
            bg=self.BG_CARD,
            fg=self.FG_TEXT,
            selectcolor=self.BG_INPUT,
            activebackground=self.BG_CARD
        )
        self.auto_chk.pack(side="left")

        save_btn = tk.Button(
            opt_frame,
            text="Save Credentials",
            font=("Segoe UI", 9, "bold"),
            bg="#313244",
            fg=self.COLOR_GREEN,
            activebackground="#45475a",
            relief="flat",
            cursor="hand2",
            padx=12,
            pady=4,
            command=self.on_save_credentials
        )
        save_btn.pack(side="right")

        # ------------------ 4. Activity Log Card ------------------
        log_frame = tk.LabelFrame(
            self.root,
            text=" Live Activity Log ",
            font=("Segoe UI", 9, "bold"),
            fg=self.COLOR_BLUE,
            bg=self.BG_CARD,
            bd=1,
            relief="groove",
            padx=10,
            pady=8
        )
        log_frame.pack(fill="both", expand=True, padx=22, pady=(0, 15))

        self.log_box = tk.Text(
            log_frame,
            bg=self.BG_INPUT,
            fg=self.FG_TEXT,
            font=("Consolas", 8),
            wrap="word",
            bd=0,
            padx=6,
            pady=6,
            state="disabled"
        )
        self.log_box.pack(side="left", fill="both", expand=True)

        scrollbar = tk.Scrollbar(log_frame, command=self.log_box.yview, bg=self.BG_CARD)
        scrollbar.pack(side="right", fill="y")
        self.log_box.config(yscrollcommand=scrollbar.set)

    def _toggle_password_visibility(self):
        self.pass_entry.config(show="" if self.show_pass_var.get() else "●")

    def append_log(self, message: str):
        timestamp = datetime.now().strftime("%H:%M:%S")
        formatted = f"[{timestamp}] {message}\n"

        def _insert():
            self.log_box.config(state="normal")
            self.log_box.insert("end", formatted)
            self.log_box.see("end")
            self.log_box.config(state="disabled")

        self.root.after(0, _insert)

    def update_status(self, online: bool, detail: str = ""):
        self.is_online = online
        now_time = datetime.now().strftime("%H:%M:%S")

        def _update():
            if online:
                self.status_dot.config(text="●", fg=self.COLOR_GREEN)
                self.status_text.config(text="ONLINE")
                self.status_subtext.config(text=detail or "Internet connection is active & verified")
            else:
                self.status_dot.config(text="●", fg=self.COLOR_RED)
                self.status_text.config(text="OFFLINE")
                self.status_subtext.config(text=detail or "Gateway authorization required")
            self.last_check_lbl.config(text=f"Updated: {now_time}")

        self.root.after(0, _update)

    def on_save_credentials(self):
        u = self.user_entry.get().strip()
        p = self.pass_entry.get().strip()
        url = self.url_entry.get().strip()

        if not u:
            messagebox.showwarning("Incomplete", "Please enter a Username / Roll Number.")
            return

        self.settings["username"] = u
        self.settings["password"] = p
        self.settings["portal_url"] = url
        self.settings["auto_reconnect"] = self.auto_reconnect.get()

        if portal_core.save_settings(self.settings):
            self.append_log(f"Custom credentials for '{u}' saved successfully!")
            messagebox.showinfo("Saved", f"Credentials for '{u}' saved!")
        else:
            self.append_log("Failed to save settings.")
            messagebox.showerror("Error", "Could not save credentials.")

    def on_connect_clicked(self):
        if self.is_busy:
            return

        u = self.user_entry.get().strip()
        p = self.pass_entry.get().strip()
        url = self.url_entry.get().strip()

        if not u:
            messagebox.showwarning("Input Required", "Please enter your Username / Roll Number.")
            return
        if not p:
            messagebox.showwarning("Input Required", "Please enter your Password.")
            return

        # Auto-save credentials on connect
        self.settings["username"] = u
        self.settings["password"] = p
        self.settings["portal_url"] = url
        self.settings["auto_reconnect"] = self.auto_reconnect.get()
        portal_core.save_settings(self.settings)

        def _run():
            self.is_busy = True
            self.append_log(f"Authenticating '{u}' with custom credentials...")
            self.root.after(0, lambda: self.status_text.config(text="AUTHENTICATING..."))
            self.root.after(0, lambda: self.status_dot.config(fg=self.COLOR_YELLOW))

            success, msg = portal_core.login(url, u, p)
            if success:
                self.append_log(f"SUCCESS: {msg}")
                time.sleep(1)
                online = portal_core.check_internet()
                self.update_status(online, msg)
                if online:
                    self.append_log("Internet connection confirmed ONLINE!")
            else:
                self.append_log(f"FAILED: {msg}")
                self.update_status(False, msg)

            self.is_busy = False

        threading.Thread(target=_run, daemon=True).start()

    def on_disconnect_clicked(self):
        if self.is_busy:
            return

        u = self.user_entry.get().strip()
        url = self.url_entry.get().strip()

        def _run():
            self.is_busy = True
            self.append_log(f"Disconnecting user '{u}'...")
            success, msg = portal_core.logout(url, u)
            self.append_log(f"Portal: {msg}")
            self.update_status(False, "Logged out by user")
            self.is_busy = False

        threading.Thread(target=_run, daemon=True).start()

    def _start_background_worker(self):
        def _worker():
            self.append_log("Connection monitor active...")
            while self.is_monitoring:
                try:
                    online = portal_core.check_internet(timeout=2.0)
                    if online:
                        if not self.is_online:
                            self.append_log("Internet status: ONLINE")
                        self.update_status(True, "Connected to Internet")
                    else:
                        if self.is_online:
                            self.append_log("Connection lost: OFFLINE")
                        self.update_status(False, "Offline - Authorization required")

                        if self.auto_reconnect.get() and not self.is_busy:
                            u = self.user_entry.get().strip()
                            p = self.pass_entry.get().strip()
                            url = self.url_entry.get().strip()

                            if u and p:
                                self.append_log(f"Auto-reconnecting '{u}'...")
                                succ, msg = portal_core.login(url, u, p)
                                if succ:
                                    self.append_log(f"Auto-login success: {msg}")
                                    self.update_status(True, msg)
                                else:
                                    self.append_log(f"Auto-login error: {msg}")

                except Exception:
                    pass

                time.sleep(10)

        threading.Thread(target=_worker, daemon=True).start()


def main():
    root = tk.Tk()
    app = ModernPortalGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
