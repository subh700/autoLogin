"""
Core network module for Sophos / Cyberoam Captive Portal.
Supports custom username & password, user profiles, and cross-platform configuration storage.
"""

import os
import sys
import json
import time
import urllib.request
import urllib.parse
import xml.etree.ElementTree as ET
from typing import Tuple, Dict, Any

def get_storage_dir() -> str:
    """Returns platform-specific user data directory for persistent settings."""
    if sys.platform.startswith("win"):
        base = os.getenv("APPDATA", os.path.expanduser("~"))
        storage = os.path.join(base, "NIT_Sikkim_Portal")
    else:
        base = os.getenv("XDG_CONFIG_HOME", os.path.expanduser("~/.config"))
        storage = os.path.join(base, "nit_sikkim_portal")
    
    os.makedirs(storage, exist_ok=True)
    return storage

CONFIG_JSON_PATH = os.path.join(get_storage_dir(), "settings.json")

def load_settings() -> Dict[str, Any]:
    """Load settings and user profiles from JSON storage or fallback to .env."""
    defaults = {
        "portal_url": "http://10.100.20.1:8090/httpclient.html",
        "username": "",
        "password": "",
        "check_interval": 60,
        "auto_reconnect": True,
        "profiles": {}
    }

    # 1. Try JSON storage first
    if os.path.exists(CONFIG_JSON_PATH):
        try:
            with open(CONFIG_JSON_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
                defaults.update(data)
                return defaults
        except Exception:
            pass

    # 2. Fallback to .env in local folder if present
    env_candidates = [
        os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"),
        os.path.join(os.getcwd(), ".env")
    ]
    for ep in env_candidates:
        if os.path.exists(ep):
            try:
                with open(ep, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith("#") and "=" in line:
                            k, v = line.split("=", 1)
                            k = k.strip().upper()
                            v = v.strip().strip("'\"")
                            if k == "PORTAL_URL": defaults["portal_url"] = v
                            elif k == "PORTAL_USERNAME": defaults["username"] = v
                            elif k == "PORTAL_PASSWORD": defaults["password"] = v
                            elif k == "CHECK_INTERVAL": defaults["check_interval"] = int(v)
                            elif k == "AUTO_RECONNECT": defaults["auto_reconnect"] = v.lower() in ("true", "1")
                break
            except Exception:
                pass

    return defaults

def save_settings(settings: Dict[str, Any]) -> bool:
    """Save custom settings to persistent storage."""
    try:
        with open(CONFIG_JSON_PATH, "w", encoding="utf-8") as f:
            json.dump(settings, f, indent=2)
        
        # Also try to update local .env if writable
        local_env = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
        try:
            with open(local_env, "w", encoding="utf-8") as f:
                f.write(f"PORTAL_URL={settings.get('portal_url', '')}\n")
                f.write(f"PORTAL_USERNAME={settings.get('username', '')}\n")
                f.write(f"PORTAL_PASSWORD={settings.get('password', '')}\n")
                f.write(f"CHECK_INTERVAL={settings.get('check_interval', 60)}\n")
                f.write(f"AUTO_RECONNECT={'true' if settings.get('auto_reconnect') else 'false'}\n")
        except Exception:
            pass

        return True
    except Exception:
        return False

def check_internet(timeout: float = 2.5) -> bool:
    """Check whether actual internet access is established."""
    endpoints = [
        "http://connectivitycheck.gstatic.com/generate_204",
        "http://www.google.com/generate_204",
        "http://1.1.1.1"
    ]
    for ep in endpoints:
        try:
            req = urllib.request.Request(ep, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                final_url = resp.geturl().lower()
                if "10.100.20.1" in final_url or "httpclient" in final_url:
                    return False
                if resp.status in (200, 204):
                    return True
        except Exception:
            continue
    return False

def get_login_endpoint(portal_url: str) -> str:
    base = portal_url.rsplit("/", 1)[0] if "/" in portal_url else portal_url
    return f"{base}/login.xml"

def get_logout_endpoint(portal_url: str) -> str:
    base = portal_url.rsplit("/", 1)[0] if "/" in portal_url else portal_url
    return f"{base}/logout.xml"

def login(portal_url: str, username: str, password: str, timeout: float = 6.0) -> Tuple[bool, str]:
    """Authenticate with custom username & password."""
    if not username.strip():
        return False, "Please enter a valid Username / Roll Number"
    if not password:
        return False, "Please enter a Password"

    endpoint = get_login_endpoint(portal_url)
    payload = urllib.parse.urlencode({
        "mode": "191",
        "username": username.strip(),
        "password": password,
        "a": str(int(time.time() * 1000)),
        "producttype": "0"
    }).encode("utf-8")

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Content-Type": "application/x-www-form-urlencoded",
        "Referer": portal_url
    }

    try:
        req = urllib.request.Request(endpoint, data=payload, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw_xml = resp.read().decode("utf-8", errors="ignore").strip()

        try:
            root = ET.fromstring(raw_xml)
            status = (root.findtext("status") or "").strip().upper()
            msg = (root.findtext("message") or "").replace("{username}", username).strip()
        except Exception:
            status = "LIVE" if "live" in raw_xml.lower() else "UNKNOWN"
            msg = raw_xml[:100]

        if status == "LIVE":
            return True, msg or "Signed in successfully"
        else:
            return False, f"[{status}] {msg or 'Login failed'}"
    except Exception as e:
        return False, f"Connection error: {e}"

def logout(portal_url: str, username: str, timeout: float = 5.0) -> Tuple[bool, str]:
    """Logout custom username."""
    endpoint = get_logout_endpoint(portal_url)
    payload = urllib.parse.urlencode({
        "mode": "193",
        "username": username.strip(),
        "a": str(int(time.time() * 1000)),
        "producttype": "0"
    }).encode("utf-8")

    headers = {
        "User-Agent": "Mozilla/5.0",
        "Content-Type": "application/x-www-form-urlencoded"
    }

    try:
        req = urllib.request.Request(endpoint, data=payload, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw_xml = resp.read().decode("utf-8", errors="ignore").strip()

        try:
            root = ET.fromstring(raw_xml)
            msg = (root.findtext("message") or "Signed out successfully").strip()
            return True, msg
        except Exception:
            return True, "Signed out"
    except Exception as e:
        return False, f"Logout error: {e}"
