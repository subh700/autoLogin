# Kali Linux Captive Portal Auto-Login

Lightweight, concise auto-login keeper for NIT Sikkim / Sophos Firewall captive portals on Kali Linux.

---

## Files

- `.env` : Holds your login credentials and settings.
- `login.py` : Native Python 3 script (zero dependencies, works out-of-the-box).
- `login.sh` : Native Bash script (uses `curl`, zero dependencies).
- `install_service.sh` : Optional 1-click script to run it automatically as a background systemd service on boot.

---

## Quick Start on Kali Linux

1. **Make scripts executable**:
   ```bash
   chmod +x login.py login.sh install_service.sh
   ```

2. **Run via Python**:
   ```bash
   python3 login.py
   ```

3. **Or run via Bash (`curl`)**:
   ```bash
   ./login.sh
   ```

---

## Run Automatically in the Background (Systemd Service)

To have Kali Linux automatically log you in on boot / WiFi connection:

```bash
sudo bash install_service.sh
```

- Check service status:
  ```bash
  sudo systemctl status portal-login
  ```
- View live logs:
  ```bash
  sudo journalctl -u portal-login -f
  ```
- Stop the service:
  ```bash
  sudo systemctl stop portal-login
  ```
