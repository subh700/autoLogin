#!/usr/bin/env bash
# Install & Enable systemd service on Kali Linux

if [ "$EUID" -ne 0 ]; then
    echo "Please run as root: sudo bash install_service.sh"
    exit 1
fi

DEST_DIR="/opt/kali_portal_login"
echo "[+] Copying files to $DEST_DIR..."
mkdir -p "$DEST_DIR"
cp -r ./* "$DEST_DIR/"
chmod +x "$DEST_DIR/login.py" "$DEST_DIR/login.sh"

echo "[+] Installing systemd service..."
cp "$DEST_DIR/portal-login.service" /etc/systemd/system/
systemctl daemon-reload
systemctl enable portal-login.service
systemctl restart portal-login.service

echo "[✓] Service installed and started!"
echo "Check status with: sudo systemctl status portal-login"
