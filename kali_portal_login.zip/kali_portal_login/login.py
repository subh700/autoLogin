#!/usr/bin/env python3
"""
NIT Sikkim / Sophos Captive Portal Auto-Login (Kali Linux & Linux)
Zero external dependencies. Reads credentials directly from .env.
"""

import os, time, urllib.request, urllib.parse, xml.etree.ElementTree as ET

# Load .env without requiring pip packages
env_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
if os.path.exists(env_file):
    for line in open(env_file, encoding="utf-8"):
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            os.environ[k.strip()] = v.strip().strip("'\"")

URL = os.getenv("PORTAL_URL", "http://10.100.20.1:8090/httpclient.html")
USER = os.getenv("PORTAL_USERNAME")
PWD = os.getenv("PORTAL_PASSWORD")
LOGIN_URL = f"{URL.rsplit('/', 1)[0]}/login.xml"
INTERVAL = int(os.getenv("CHECK_INTERVAL", "60"))

def is_online():
    try:
        return urllib.request.urlopen("http://connectivitycheck.gstatic.com/generate_204", timeout=3).status == 204
    except Exception:
        return False

def login():
    data = urllib.parse.urlencode({"mode": "191", "username": USER, "password": PWD, "a": int(time.time() * 1000), "producttype": "0"}).encode()
    try:
        with urllib.request.urlopen(urllib.request.Request(LOGIN_URL, data=data, method="POST"), timeout=5) as r:
            xml = ET.fromstring(r.read().decode(errors="ignore"))
            status = xml.findtext("status", "").strip().upper()
            msg = xml.findtext("message", "").replace("{username}", USER).strip()
            print(f"[{time.strftime('%H:%M:%S')}] Portal: {msg or status}", flush=True)
            return status == "LIVE"
    except Exception as e:
        print(f"[{time.strftime('%H:%M:%S')}] Connection error: {e}", flush=True)
        return False

if __name__ == "__main__":
    if not USER or not PWD:
        raise SystemExit("Error: Set PORTAL_USERNAME and PORTAL_PASSWORD in .env")

    print(f"[{time.strftime('%H:%M:%S')}] Kali Captive Portal Auto-Login started for {USER}", flush=True)
    while True:
        if not is_online():
            print(f"[{time.strftime('%H:%M:%S')}] Offline. Logging in...", flush=True)
            login()
        else:
            print(f"[{time.strftime('%H:%M:%S')}] Online. Connection OK.", flush=True)
        time.sleep(INTERVAL)
