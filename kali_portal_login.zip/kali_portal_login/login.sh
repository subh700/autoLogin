#!/usr/bin/env bash
# ==============================================================
# NIT Sikkim / Sophos Captive Portal Auto-Login for Kali Linux
# Uses curl (built-in) & reads strictly from .env
# ==============================================================

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$DIR/.env"

if [ ! -f "$ENV_FILE" ]; then
    echo "[!] Error: .env file not found in $DIR"
    exit 1
fi

# Load .env variables cleanly
export $(grep -v '^#' "$ENV_FILE" | xargs)

if [ -z "$PORTAL_USERNAME" ] || [ -z "$PORTAL_PASSWORD" ]; then
    echo "[!] Error: Set PORTAL_USERNAME and PORTAL_PASSWORD in .env"
    exit 1
fi

LOGIN_URL="${PORTAL_URL%/httpclient.html}/login.xml"
INTERVAL="${CHECK_INTERVAL:-60}"

is_online() {
    local code
    code=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 3 "http://connectivitycheck.gstatic.com/generate_204")
    [ "$code" = "204" ]
}

do_login() {
    local timestamp=$(date +%s%3N)
    local payload="mode=191&username=${PORTAL_USERNAME}&password=${PORTAL_PASSWORD}&a=${timestamp}&producttype=0"
    
    local resp
    resp=$(curl -s -X POST "$LOGIN_URL" \
        -H "Content-Type: application/x-www-form-urlencoded" \
        -d "$payload" \
        --connect-timeout 5)

    if echo "$resp" | grep -q "LIVE"; then
        echo "[$(date +%T)] SUCCESS: Logged in as ${PORTAL_USERNAME}!"
        return 0
    else
        echo "[$(date +%T)] FAILED: Check credentials or portal response: $resp"
        return 1
    fi
}

echo "=== Kali Linux Captive Portal Auto-Login ==="
echo "User     : $PORTAL_USERNAME"
echo "Gateway  : $LOGIN_URL"
echo "Interval : Every ${INTERVAL}s"
echo "Press Ctrl + C to stop."
echo "============================================"

while true; do
    if ! is_online; then
        echo "[$(date +%T)] Offline detected. Authenticating..."
        do_login
    else
        echo "[$(date +%T)] Online. Connection is active."
    fi
    sleep "$INTERVAL"
done
